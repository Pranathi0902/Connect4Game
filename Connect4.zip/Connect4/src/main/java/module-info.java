module com.pranathi.connectfour.connect4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.pranathi.connectfour.connect4 to javafx.fxml;
    exports com.pranathi.connectfour.connect4;
}